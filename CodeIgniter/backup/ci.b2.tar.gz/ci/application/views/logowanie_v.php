<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<title>Logowanie</title>

</head>
<body>

<div id="container">
	<h1>Logowanie</h1>

	<div id="body">
		Logowanie czysta strona
		</div>
</div>

</body>
</html>
