<div class="panel-body">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="alert-message alert-message-success">
					<h3>Aktualności. Dziś jest <strong><?php echo date("d-m-Y") ?></strong></h3>
					<?=$zadaniek?>
				</div>
			</div>
		</div>
	<div>			     
</div>  
				</div>