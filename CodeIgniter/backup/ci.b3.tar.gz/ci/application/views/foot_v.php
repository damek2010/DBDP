<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
</div>  
				</div>
				<div class="navbar navbar-default navbar-fixed-bottom">
					<div class="container">
						<p class="navbar-text pull-left">� 2017 DBDP SPRINT IS GOOOOD!!!!</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
