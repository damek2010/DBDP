<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

					<div class="panel-body" style="margin-bottom: 50px;">
					    <div class="row">
						<form class="form-horizontal">
						<fieldset>

						<!-- Form Name -->
						<center><legend>Projekty</legend></center>

						<!-- Text input-->
						
						<?= $look; ?>
						
						</fieldset>
						</form>
					</div>
				</div>
				    
<script type="text/javascript" language="JavaScript 1.5">
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>


