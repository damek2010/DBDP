<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>


					<div class="panel-body">
					    <div class="row">
						<?= $del; ?>
					</div>

